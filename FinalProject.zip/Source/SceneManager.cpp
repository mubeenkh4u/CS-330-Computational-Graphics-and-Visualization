///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ================
// This file contains the implementation of the `SceneManager` class, which is 
// responsible for managing the preparation and rendering of 3D scenes. It 
// handles textures, materials, lighting configurations, and object rendering.
//
// AUTHOR: Brian Battersby
// INSTITUTION: Southern New Hampshire University (SNHU)
// COURSE: CS-330 Computational Graphics and Visualization
//
// INITIAL VERSION: November 1, 2023
// LAST REVISED: December 1, 2024
//
// RESPONSIBILITIES:
// - Load, bind, and manage textures in OpenGL.
// - Define materials and lighting properties for 3D objects.
// - Manage transformations and shader configurations.
// - Render complex 3D scenes using basic meshes.
//
// NOTE: This implementation leverages external libraries like `stb_image` for 
// texture loading and GLM for matrix and vector operations.
///////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////
// Addition of Images for Textures to various 3D Shapes in this assignment.
// Code Updated to reflect Module 5 - Assignment (LoadSceneTextures() Method)
// UPDATE DATE: February 23, 2025
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#define GLM_ENABLE_EXPERIMENTAL
#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();

	// Added Texture Collection Loop

	// initialize the texture collection
	for (int i = 0; i < 16; i++)
	{
		m_textureIDs[i].tag = "/0";
		m_textureIDs[i].ID = -1;
	}
	m_loadedTextures = 0;
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;

	// destroy the created OpenGL textures
	DestroyGLTextures();
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glDeleteTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/***********************************************************
  *  DefineObjectMaterials()
  *
  *  This method is used for configuring the various material
  *  settings for all of the objects within the 3D scene.
  ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	/*** STUDENTS - add the code BELOW for defining object materials. ***/
	/*** There is no limit to the number of object materials that can ***/
	/*** be defined. Refer to the code in the OpenGL Sample for help  ***/

	/*
	* Sample Object with definitions and parameters
	*
	OBJECT_MATERIAL plasticMaterial;													// Define a new material object called "plasticMaterial".
	plasticMaterial.diffuseColor = glm::vec3(0.8f, 0.4f, 0.8f);							// Set Diffuse color which determines the base color of the material under light.
	plasticMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);						// Set the specular color, which controls how shiny the surface is. Low = low reflectivity, vice versa.
	plasticMaterial.shininess = 1.0;													// Shininess factor: A value of 1.0 means it has very low shininess, resulting in a matte appearance.
	plasticMaterial.tag = "plastic";													// Assign a tag to identify the material type.
	*/

	OBJECT_MATERIAL plasticMaterial;
	plasticMaterial.diffuseColor = glm::vec3(0.8f, 0.4f, 0.8f);
	plasticMaterial.specularColor = glm::vec3(1.5f, 1.5f, 1.5f);
	plasticMaterial.shininess = 120.0;
	plasticMaterial.tag = "plastic";

	m_objectMaterials.push_back(plasticMaterial);

	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.6f, 0.5f, 0.2f);
	woodMaterial.specularColor = glm::vec3(0.5f, 0.5f, 0.5f);	// 0.1f, 0.2f, 0.2f
	woodMaterial.shininess = 0.1;
	woodMaterial.tag = "wood";

	m_objectMaterials.push_back(woodMaterial);

	OBJECT_MATERIAL metalMaterial;
	metalMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	metalMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.8f);
	metalMaterial.shininess = 8.0;
	metalMaterial.tag = "metal";

	m_objectMaterials.push_back(metalMaterial);

	OBJECT_MATERIAL glassMaterial;
	glassMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.2f);
	glassMaterial.specularColor = glm::vec3(0.9f, 0.9f, 0.8f);
	glassMaterial.shininess = 10.0;
	glassMaterial.tag = "glass";

	m_objectMaterials.push_back(glassMaterial);

	OBJECT_MATERIAL tileMaterial;
	tileMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	tileMaterial.specularColor = glm::vec3(0.7f, 0.7f, 0.7f);
	tileMaterial.shininess = 6.0;
	tileMaterial.tag = "tile";

	m_objectMaterials.push_back(tileMaterial);

	OBJECT_MATERIAL stoneMaterial;
	stoneMaterial.diffuseColor = glm::vec3(0.5f, 0.5f, 0.5f);
	stoneMaterial.specularColor = glm::vec3(0.73f, 0.3f, 0.3f);
	stoneMaterial.shininess = 6.0;
	stoneMaterial.tag = "stone";

	m_objectMaterials.push_back(stoneMaterial);

	// Box Material - Cardboard/Paper
	OBJECT_MATERIAL tissueBoxMaterial;
	tissueBoxMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.8f);  // Light brown/white color
	tissueBoxMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);  // Low specular for a matte look
	tissueBoxMaterial.shininess = 10.0f;  // Very low shininess for paper
	tissueBoxMaterial.tag = "box";

	m_objectMaterials.push_back(tissueBoxMaterial);

	// Tissue Paper Material - Soft and Slightly Transparent
	OBJECT_MATERIAL paperMaterial;
	paperMaterial.diffuseColor = glm::vec3(1.0f, 1.0f, 1.0f);  // White tissue color
	paperMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f);  // Almost no specular
	paperMaterial.shininess = 5.0f;  // Very low shininess
	paperMaterial.tag = "paper";

	m_objectMaterials.push_back(paperMaterial);

}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is called to add and configure the light
 *  sources for the 3D scene.  There are up to 4 light sources.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// this line of code is NEEDED for telling the shaders to render 
	// the 3D scene with custom lighting, if no light sources have
	// been added then the display window will be black - to use the 
	// default OpenGL lighting then comment out the following line
	m_pShaderManager->setBoolValue(g_UseLightingName, true);							// main command to enable all scene related lighting

	/*** STUDENTS - add the code BELOW for setting up light sources ***/
	/*** Up to four light sources can be defined. Refer to the code ***/
	/*** in the OpenGL Sample for help                              ***/

	/*
	* Parameter Definitions:
	*	Direction: Where the light is pointing towards
	*	Ambient		- Defines the color of the ambient light being emitted.
	*	Diffuse		- Defines the color of the diffuse light being emitted.
	*	Specular	- Defines the color of the specular light being emitted.
	*	Constant	- Linear, Quadratic: Controls light falloff over distance (attenuation).
	*	Cuttoff		- The clipping circle diameter of the inner light beam
	*	OuterCutOff � the clipping circle diameter of the outer light beam
	*	bActive		� This is a boolean value that indicates the light source is active
	*/

	// Directional Light Source (used as main light source)
	m_pShaderManager->setVec3Value("directionalLight.direction", -5.0f, 10.0f, -4.0f);	// 0.2f, -1.0f, -0.3f
	m_pShaderManager->setVec3Value("directionalLight.ambient", 0.2f, 0.2f, 0.2f);		// 0.1f, 0.0f, 0.1f
	m_pShaderManager->setVec3Value("directionalLight.diffuse", 0.8f, 0.8f, 0.8f);		// 0.8f, 0.8f, 0.8f
	m_pShaderManager->setVec3Value("directionalLight.specular", 0.5f, 0.5f, 0.5f);		// 0.2f, 0.2f, 0.2f
	m_pShaderManager->setBoolValue("directionalLight.bActive", true);

	// point light 1 (Thermos Accent)
	m_pShaderManager->setVec3Value("pointLights[0].position", -4.0f, 5.0f, -3.0f);	// -10.0f, 10.0f, 4.0f
	m_pShaderManager->setVec3Value("pointLights[0].ambient", 0.1f, 0.1f, 0.1f);
	m_pShaderManager->setVec3Value("pointLights[0].diffuse", 1.0f, 1.0f, 1.0f);		// 0.8f, 0.8f, 0.8f
	m_pShaderManager->setVec3Value("pointLights[0].specular", 0.0f, 0.0f, 0.0f);
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	// point light 2 (Floor/Wall)
	m_pShaderManager->setVec3Value("pointLights[1].position", 5.0f, 5.0f, -5.0f);	//  0.0f, 6.0f, 0.0f
	m_pShaderManager->setVec3Value("pointLights[1].ambient", 0.1f, 0.1f, 0.1f);		// 0.05f, 0.05f, 0.05f
	m_pShaderManager->setVec3Value("pointLights[1].diffuse", 0.8f, 0.8f, 0.8f);		// 0.5f, 0.5f, 0.5f
	m_pShaderManager->setVec3Value("pointLights[1].specular", 0.1f, 0.1f, 0.1f);	// 0.2f, 0.2f, 0.2f
	// m_pShaderManager->setFloatValue("pointLights[1].quadratic", 0.02f);
	m_pShaderManager->setBoolValue("pointLights[1].bActive", true);

	// spotlight Integration (attached to 3D Camera)
	// m_pShaderManager->setVec3Value("spotLight.position", -5.0f, 10.0f, 10.0f);		// Used manual positioning of Spotlight (check viewmanager.cpp for enabling instructions)
	// m_pShaderManager->setVec3Value("spotLight.direction", 3.0f, -4.0f, -6.0f);		// Used for manual direction of light coming out of SpotLight
	m_pShaderManager->setVec3Value("spotLight.ambient", 0.5f, 0.5f, 0.5f);
	m_pShaderManager->setVec3Value("spotLight.diffuse", 1.0f, 1.0f, 1.0f);
	m_pShaderManager->setVec3Value("spotLight.specular", 2.0f, 2.0f, 2.0f);
	m_pShaderManager->setFloatValue("spotLight.constant", 1.0f);
	m_pShaderManager->setFloatValue("spotLight.linear", 0.05f);
	m_pShaderManager->setFloatValue("spotLight.quadratic", 0.01f);
	m_pShaderManager->setFloatValue("spotLight.cutOff", glm::cos(glm::radians(30.0f)));
	m_pShaderManager->setFloatValue("spotLight.outerCutOff", glm::cos(glm::radians(50.0f)));
	m_pShaderManager->setBoolValue("spotLight.bActive", true);

}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


// Adding LoadSceneTextures to help create textures from images for the 3D Objects

 /***********************************************************
  *  LoadSceneTextures()
  *
  *  This method is used for preparing the 3D scene by loading
  *  the shapes, textures in memory to support the 3D scene
  *  rendering
  ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	/*** STUDENTS - add the code BELOW for loading the textures that ***/
	/*** will be used for mapping to objects in the 3D scene. Up to  ***/
	/*** 16 textures can be loaded per scene. Refer to the code in   ***/
	/*** the OpenGL Sample for help.                                 ***/

	bool bReturn = false;

	bReturn = CreateGLTexture("./textures/WoodFloor043_4K-JPG_Color.jpg", "floor");	// Image used for texture applied to the Plane Mesh acting as floor
	bReturn = CreateGLTexture("./textures/Paint004_1K-JPG_Color.jpg", "wall");	// Image used for texture applied to the Plane acting as the wall	
	bReturn = CreateGLTexture("./textures/Metal049A_4K-PNG_Color.png", "cylinder"); // Image used for texture applied to the Thermos Main Body & Handle; Tapered Cylinder Mesh
	bReturn = CreateGLTexture("./textures/Wood067_1K-JPG_Color.jpg", "cap"); // Image used for the texture applied to the Thermos Cap
	bReturn = CreateGLTexture("./textures/SurfaceImperfections007_1K-JPG_Color.png", "glass"); // Image used for the texture applied to the Glass Mug
	bReturn = CreateGLTexture("./textures/pattern-background-flowers-backgrounds-textures-486133-1024.jpg", "box"); // Image used for the texture applied to the Tissue Box.
	bReturn = CreateGLTexture("./textures/Metal049A_4K-PNG_Metalness.png", "paper");

	// after the texture image data is loaded into memory, the
	// loaded textures need to be bound to texture slots - there
	// are a total of 16 available slots for scene textures
	BindGLTextures();
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// define the materials for objects in the scene
	DefineObjectMaterials();
	// add and define the light sources for the scene
	SetupSceneLights();
	// load the textures for the 3D scene
	LoadSceneTextures();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadSemiSphereMesh();		// Created my half Sphere Mesh
	m_basicMeshes->LoadHalfTorusMesh();			// Created my half Torus Mesh
	m_basicMeshes->LoadTorusMesh();
	m_basicMeshes->LoadTaperedCylinderMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadExtraTorusMesh1();
	m_basicMeshes->LoadPyramid3Mesh();
	m_basicMeshes->LoadPyramid4Mesh();

}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// SetShaderColor(0.4f, 0.4f, 1.0f, 1.0f); // Deep Blue
	SetTextureUVScale(5.0f, 5.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("wood");
	SetShaderTexture("floor");	// Texture for better object reprsentation

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 9.0f, -10.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// set the color values into the shader
	// SetShaderColor(0.4f, 0.4f, 1.0f, 1.0f); // Deep Blue
	SetTextureUVScale(5.0f, 5.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("stone");
	SetShaderTexture("wall");	// Texture for better object reprsentation

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();

	/****************************************************************/
	/** Render the Half Sphere Cap (Half Sphere) */
	/****************************************************************/
	// set the XYZ scale for the sphere cap
	scaleXYZ = glm::vec3(1.5f, 1.5f, 1.5f); // Proportional sphere for the top

	// set the XYZ rotation for the sphere cap
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the sphere cap
	positionXYZ = glm::vec3(-4.0f, 9.0f, 0.0f); // Top of the cylinder

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the sphere cap
	// SetShaderColor(0.8f, 0.4f, 1.0f, 1.0f); // Purple sphere
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cap");	// Texture for better object reprsentation

	// draw the sphere mesh with the transformation values
	m_basicMeshes->DrawSemiSphereMesh();

	/****************************************************************/
	/** Render the Middle Body (Tapered Cylinder Top Half) */
	/****************************************************************/
	// set the XYZ scale for the middle tapered cylinder
	scaleXYZ = glm::vec3(3.0f, 9.0f, 3.0f); // Tall and proportionate

	// set the XYZ rotation for the middle tapered cylinder
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the middle tapered cylinder
	positionXYZ = glm::vec3(-4.0f, 0.1f, 0.0f); // Centered on the floor

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the middle tapered cylinder
	// SetShaderColor(0.4f, 0.6f, 1.0f, 1.0f); // Light blue cylinder
	SetTextureUVScale(1.0f ,1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cylinder");	// Texture for better object reprsentation

	// draw the tapered cylinder mesh with the transformation values
	m_basicMeshes->DrawTaperedCylinderMesh(true, true);	// Drawing Top and Bottom of Cylinder for better meshing with sphere for lid

	/****************************************************************/
	/** Render the Thermos Handle (Torus) */
	/****************************************************************/
	// set the XYZ scale for the thermos handle
	// scaleXYZ = glm::vec3(2.0f, 2.0f, 2.0f); // Thick and wide torus
	scaleXYZ = glm::vec3(1.8f, 1.5f, 2.0f);

	// set the XYZ rotation for the thermos handle
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 80.0f;

	// set the XYZ position for the thermos handle
	positionXYZ = glm::vec3(-5.7f, 6.5f, 0.0f); // Positioned to the left of the body

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the thermos handle
	// SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cylinder");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawExtraTorusMesh1();


	/****************************************************************/
	/** Render the Thermos Spout (Pyramid) */
	/****************************************************************/
	// set the XYZ scale for the thermos handle
	// scaleXYZ = glm::vec3(2.0f, 2.0f, 2.0f); // Thick and wide torus
	scaleXYZ = glm::vec3(1.8f, 1.5f, 2.0f);

	// set the XYZ rotation for the thermos spout
	XrotationDegrees = 5.0f;
	YrotationDegrees = 25.0f;
	ZrotationDegrees = -90.0f;

	// set the XYZ position for the thermos spout
	positionXYZ = glm::vec3(-2.4f, 8.8f, -0.0f); // Positioned to the right of the body

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the thermos spout
	// SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cylinder");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawPyramid3Mesh();

	/****************************************************************/
	/** Render the Plastic Bottle Main Body	(Cylinder)			    */
	/****************************************************************/
	// set the XYZ scale for the middle tapered cylinder
	scaleXYZ = glm::vec3(0.5f, 3.0f, 0.5f); // Tall and proportionate

	// set the XYZ rotation for the middle tapered cylinder
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the middle tapered cylinder
	positionXYZ = glm::vec3(0.0f, 0.1f, 4.0f); // Centered on the floor

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the middle tapered cylinder
	// SetShaderColor(0.4f, 0.6f, 1.0f, 1.0f); // Light blue cylinder
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cylinder");	// Texture for better object reprsentation

	// draw the tapered cylinder mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh(true, true);	// Drawing Top and Bottom of Cylinder for better meshing with sphere for lid

	/****************************************************************/
	/** Render the Half Sphere Cap (Half Sphere) */
	/****************************************************************/
	// set the XYZ scale for the sphere cap
	scaleXYZ = glm::vec3(0.3f, 1.0f, 0.3f); // Proportional sphere for the top

	// set the XYZ rotation for the sphere cap
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the sphere cap
	positionXYZ = glm::vec3(0.0f, 3.1f, 4.0f); // Top of the cylinder

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the sphere cap
	// SetShaderColor(0.8f, 0.4f, 1.0f, 1.0f); // Purple sphere
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("glass");	// Texture for better object reprsentation

	// draw the sphere mesh with the transformation values
	m_basicMeshes->DrawSemiSphereMesh();

	/****************************************************************/
	/** Render the Top Plastic Bottle (Cylinder)					*/
	/****************************************************************/
	// set the XYZ scale for the middle cylinder
	scaleXYZ = glm::vec3(0.2f, 1.0f, 0.2f); // Tall and proportionate

	// set the XYZ rotation for the middle cylinder
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the middle cylinder
	positionXYZ = glm::vec3(0.0f, 3.2f, 4.0f); // Top of the Cylinder

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the middle cylinder
	// SetShaderColor(0.4f, 0.6f, 1.0f, 1.0f); // Light blue cylinder
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("plastic");	// Material type for the object
	SetShaderTexture("cylinder");	// Texture for better object reprsentation

	// draw the tapered cylinder mesh with the transformation values
	m_basicMeshes->DrawCylinderMesh(true, true);	// Drawing Top and Bottom of Cylinder for better meshing with sphere for lid


	/****************************************************************/
	/** Render the Base of Cup (Torus)								*/
	/****************************************************************/
	// set the XYZ scale for the Base of Cup
	scaleXYZ = glm::vec3(0.8f, 0.8f, 0.8f);

	// set the XYZ rotation for the Base of Cup
	XrotationDegrees = 90.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the Base of Cup
	positionXYZ = glm::vec3(3.5f, 0.3f, 0.0f); // Positioned to the left of the body

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the Base of Cup
	// SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("glass");	// Material type for the object
	SetShaderTexture("glass");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawTorusMesh();

	/****************************************************************/
	/** Render the Main Cup Body (Half Sphere) */
	/****************************************************************/
	// set the XYZ scale for the Main Cup Body
	scaleXYZ = glm::vec3(2.5f, 4.0f, 2.5f); // Proportional sphere for the top 

	// set the XYZ rotation for the Main Cup Body
	XrotationDegrees = 180.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the Main Cup Body
	positionXYZ = glm::vec3(3.5f, 4.35f, 0.0f); // Top of the cylinder

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for Main Cup Body
	// SetShaderColor(0.8f, 0.4f, 1.0f, 1.0f); // Purple sphere
	SetShaderMaterial("glass");	// Material type for the object
	SetShaderTexture("glass");	// Texture for better object reprsentation

	// draw the sphere mesh with the transformation values
	m_basicMeshes->DrawSemiSphereMesh();

	/****************************************************************/
	/** Render the Cup Handle (Half-Torus) */
	/****************************************************************/
	// set the XYZ scale for the Cup Handle
	scaleXYZ = glm::vec3(1.0f, 1.5f, 0.5f);

	// set the XYZ rotation for the Cup Handle
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = -110.0f;

	// set the XYZ position for the Cup Handle
	positionXYZ = glm::vec3(5.55f, 2.5f, 0.0f); // Positioned to the left of the body

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the Cup Handle
	// SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("glass");	// Material type for the object
	SetShaderTexture("glass");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawHalfTorusMesh();


	/****************************************************************/
	/** Render the Tissue Box (Box) */
	/****************************************************************/
	// set the XYZ scale for the Tissue Box
	scaleXYZ = glm::vec3(5.0f, 2.3f, 5.0f);

	// set the XYZ rotation for the Cup Handle
	XrotationDegrees = 0.0f;
	YrotationDegrees = 30.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the Cup Handle
	positionXYZ = glm::vec3(9.85f, 1.2f, -3.0f); // Positioned to the right of the Cup Handle

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the Cup Handle
	// SetShaderColor(0.9f, 0.9f, 0.9f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("box");	// Material type for the object
	SetShaderTexture("box");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/** Render the Tissue Box Top Hole (Circle) */
	/****************************************************************/
	// set the XYZ scale for the Tissue Box
	scaleXYZ = glm::vec3(2.2f, 0.1f, 2.0f);

	// set the XYZ rotation for the Tissue Box Top Hole
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the Tissue Box Top Hole
	positionXYZ = glm::vec3(9.95f, 2.3f, -3.0f); // Positioned above the top layer of the box

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the Tissue Box Top Hole
	SetShaderColor(0.0f, 0.0f, 0.0f, 1.0f); // Black color
	// SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	// SetShaderMaterial("tissueBox");	// Material type for the object
	// SetShaderTexture("box");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawSphereMesh();

	/****************************************************************/
	/** Render the Tissue Paper (Pyramid Mesh) */
	/****************************************************************/
	// set the XYZ scale for the Tissue Box Top
	scaleXYZ = glm::vec3(2.3f, 3.1f, 2.3f);

	// set the XYZ rotation for the Tissue Paper
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the Tissue Paper
	positionXYZ = glm::vec3(9.9f, 3.8f, -2.9f); // Positioned above the top layer of the box

	// set the transformations into memory to be used on the drawn mesh
	SetTransformations(scaleXYZ, XrotationDegrees, YrotationDegrees, ZrotationDegrees, positionXYZ);

	// set the shader color for the Tissue Paper
	// SetShaderColor(1.0f, 1.0f, 1.0f, 1.0f); // Light gray color
	SetTextureUVScale(1.0f, 1.0f);	// Shader tiling for better object reprsentation
	SetShaderMaterial("paper");	// Material type for the object
	SetShaderTexture("paper");	// Texture for better object reprsentation

	// draw the torus mesh with the transformation values
	m_basicMeshes->DrawPyramid3Mesh();

}
